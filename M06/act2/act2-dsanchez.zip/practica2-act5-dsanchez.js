var texto = prompt("Introduce una frase:")
var letra = prompt("¿Que letra quieres buscar dentro de la frase?: ")
var veces = [];
var cont = 0;
for (cont<texto.length; cont++;) 