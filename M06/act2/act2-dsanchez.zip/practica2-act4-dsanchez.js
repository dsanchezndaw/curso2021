var palabra = prompt("Escribe la frase que quieras: ");
var posicion = palabra.substring(4,16)
    alert(posicion);

