dia = new Date();
alert("Dia de la semana: " + dia.getDate() + '\n' + "Mes del año: " + dia.getMonth() + '\n' + "Año: " + dia.getFullYear() + '\n' + "Hora: " +dia.getHours() + '\n' + "Minuto: " + dia.getMinutes() + '\n' + "Segundo: " + dia.getSeconds())
