var a1 = prompt("Introduce una cadena de texto: ");
var a2 = a1.toUpperCase();
var a3 = a1.length;
var a4 = a1.split(" ").length;
    alert("Texto: " + [a1] + "\n" + "Numero de caracteres: " + [a3] + "\n" + "Numero de palabras: " + [a4] + "\n" + "Texto en mayusculas: " + [a2] ) 