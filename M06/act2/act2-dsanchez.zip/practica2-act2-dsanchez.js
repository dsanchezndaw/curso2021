var a1 = prompt("Inroduce una cadena de texto: ");
var a2 = a2.reverse();
alert(a2); 
