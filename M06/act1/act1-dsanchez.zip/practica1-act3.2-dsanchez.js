var edad;
    edad = prompt("¿Cuantos años tienes?"); 
    edad = parseInt(edad);  
    if (!(edad != 18)) {
        alert("Voste no te 18 anys");
    } else {
        alert("Voste te 18 anys");
    }    