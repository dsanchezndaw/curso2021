var respuesta = confirm("Presione uno de los botones que ve es este cuadro", "Texto");
alert ((respuesta) ? "Ha pulsado el boton [ACEPTAR] " : "Ha pulsado el boton [CANCELAR] ")